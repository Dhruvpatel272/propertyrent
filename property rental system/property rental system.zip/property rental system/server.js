// Import required modules
const express = require('express');
const mongoose = require('mongoose');

// Create an instance of Express
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://localhost/house_rental_system')
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Failed to connect to MongoDB:', error);
  });

// Define House schema
const houseSchema = new mongoose.Schema({
  title: String,
  addedDate: Date,
  location: String
});

// Create House model
const House = mongoose.model('House', houseSchema);

// Set up middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Define routes
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.get('/about', (req, res) => {
  res.sendFile(__dirname + '/about.html');
});

app.get('/houses', (req, res) => {
  House.find({}, (err, houses) => {
    if (err) {
      console.error('Failed to fetch houses:', err);
      res.status(500).json({ error: 'Failed to fetch houses' });
    } else {
      res.json(houses);
    }
  });
});

app.get('/contact', (req, res) => {
  res.sendFile(__dirname + '/contact.html');
});

app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/login.html');
});

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  contact: String,
  address: String
});


const User = mongoose.model('User', userSchema);

// Routes
app.post('/houses', async (req, res) => {
    const { name, email, contact, address } = req.body;

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message:' is already in use' });
        }

        const newUser = await User.create({ name, email, contact, address });
        res.status(201).json({ message: 'User created successfully', user: newUser });
    } catch (error) {
        console.error('Error creating user:', error);
        res.status(500).json({ message: 'Error creating user', error: error.message });
    }
});


const Contact = mongoose.model('contact', userSchema); // Change model name to 'contact'

// Routes
app.post('/contact', async (req, res) => {
    const { name, email, contact, address } = req.body;

    try {
        const existingContact = await Contact.findOne({ email }); // Change to look for existing contact
        if (existingContact) {
            return res.status(400).json({ message: 'Contact already exists' });
        }

        const newContact = await Contact.create({ name, email, contact, address }); // Change to create a new contact
        res.status(201).json({ message: 'Contact created successfully', contact: newContact });
    } catch (error) {
        console.error('Error creating contact:', error);
        res.status(500).json({ message: 'Error creating contact', error: error.message });
    }
});


const houses = mongoose.model('houses', houseSchema); // Change model name to 'House'

// Routes
app.post('/houses', async (req, res) => {
    const { title, addedDate, location } = req.body; // Update variable names to match house attributes

    try {
        const existingHouse = await House.findOne({ title }); // Check for existing house based on title instead of email
        if (existingHouse) {
            return res.status(400).json({ message: 'House already exists' });
        }

        const newHouse = await House.create({ title, addedDate, location }); // Create a new house
        res.status(201).json({ message: 'House created successfully', house: newHouse });
    } catch (error) {
        console.error('Error creating house:', error);
        res.status(500).json({ message: 'Error creating house', error: error.message });
    }
});


// Start the server
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
